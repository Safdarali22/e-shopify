package com.rafy.e_shoping_updated;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
