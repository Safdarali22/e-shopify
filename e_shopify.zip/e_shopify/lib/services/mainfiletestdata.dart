import 'dart:convert';
import 'dart:io';

void main() async {
  // var dataInString = await rootBundle.loadString('lib/services/test_data.json');
  // var jsonData = jsonDecode(dataInString);
  // print(jsonData);
  var input = await File("lib/services/test_data.json").readAsString();
  var data = jsonDecode(input);
  print(data.length);
}
