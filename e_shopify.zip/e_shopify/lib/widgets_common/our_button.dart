import 'package:e_shoping_updated/consts/consts.dart';

Widget ourButton({
  onpress,
  bgColor,
  textColor,
  String? title,
}) {
  return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: bgColor,
        padding: const EdgeInsets.all(12),
      ),
      onPressed: onpress,
      child: title!.text.color(textColor).fontFamily(bold).make());
}
