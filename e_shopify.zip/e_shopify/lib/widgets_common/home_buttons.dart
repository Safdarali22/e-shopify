import 'package:e_shoping_updated/consts/consts.dart';

Widget homeButton({width, height, String? title, icon, onpress}) {
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Image.asset(icon, width: 26),
      5.heightBox,
      title!.text.fontFamily(semibold).color(darkFontGrey).center.make(),
    ],
  ).box.rounded.white.shadowSm.size(width, height).make();
}
