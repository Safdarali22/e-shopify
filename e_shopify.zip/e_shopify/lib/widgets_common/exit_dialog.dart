import 'package:e_shoping_updated/consts/consts.dart';
import 'package:e_shoping_updated/widgets_common/our_button.dart';
import 'package:flutter/services.dart';

Widget exitDialog(context) {
  return Dialog(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        "Confirm".text.color(darkFontGrey).fontFamily(bold).size(18).make(),
        const Divider(),
        10.heightBox,
        "Are you sure you want to exit?"
            .text
            .color(darkFontGrey)
            .fontFamily(semibold)
            .size(16)
            .make(),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ourButton(
                onpress: () {
                  SystemNavigator.pop();
                },
                title: 'Yes',
                bgColor: redColor,
                textColor: whiteColor),
            ourButton(
                onpress: () {
                  Navigator.pop(context);
                },
                title: 'No',
                bgColor: redColor,
                textColor: whiteColor),
          ],
        )
      ],
    ).box.color(lightGrey).padding(const EdgeInsets.all(12)).roundedSM.make(),
  );
}
