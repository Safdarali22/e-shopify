const appname = "E-Shopify";
const appversion = "Version 1.0.0";
const credits = "@Usindh";
const email = "Email";
const emailHint = "xyz@gmail.com";
const password = "Password";
const passwordHint = "********";
const retypePassword = "Confirm Password";
const name = "Name";
const nameHint = "Username";
const termsAndConditions = "terms and conditions";
const privacyPolicy = "Privacy & policy";
const loggedIn = "Logged In successfully";
const loggedOut = "Logged Out Successfully";
const forgetPassword = "Forget Password";
const login = "Log in";
const signUp = "Sign Up";
const logOut = "Logout";
const createNewAccount = "or, create a new account";
const loginWith = "Log in with";
const alreadyhaveAccount = "Already have an Account ?";
const home = "Home",
    categories = "Categories",
    cart = "Cart",
    account = "Account";
const oldPassword = "Old Password", newpassword = 'New Password';

// Home Screen Strings
const searchAnything = "Search Anything...",
    todayDeal = "Today's Deal",
    flashSale = "Flash Sale",
    topSellers = "Top Sellers",
    brands = "Brands",
    topCategories = "Top Categories",
    womenDresses = "Women Dresses",
    girlsWatches = "Girls Watches",
    mobilePhones = "Mobile Phones",
    boysGlasses = "Boys Glasses",
    tshirts = "TShirts",
    girlsDresses = "Girls Dresses",
    featuredProduct = "Featured Product",
    featuredCategories = 'Featured Categories';

const womenClothing = "Women Clothing",
    menClothingFashion = "Men Clothing & Fashion",
    compAccess = "Computer & Accessories",
    automobile = "Automobile",
    kidtoys = "Kids & Toys",
    sports = "Sports",
    jewelery = "Jewelery",
    cellphone = "Cellphone & Tabs",
    furniture = "Furniture";
const womenClothings = "Women Clothing",
    menClothingFashions = "Men Clothing & Fashion",
    compAccesss = "Computer & Accessories",
    automobiles = "Automobile",
    kidtoyss = "Kids & Toys",
    sportss = "Sports",
    jewelerys = "Jewelery",
    cellphones = "Cellphone & Tabs",
    furnitures = "Furniture";


const sellerPolicy = "Seller Policy",
    video = "Video",
    review = "Review",
    returnPolicy = "Return Policy",
    supportPolicy = "Support Policy",
    productAlsoLike = "Products you may also like";

// profile strings

const wishlist = "My Wishlist", orders = "My Orders", messages = "Messages";

const paypal = "Pay Pal", stripe = "Stripe", cod = "Cash on Delivery";
