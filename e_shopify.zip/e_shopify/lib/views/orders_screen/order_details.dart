import '../../consts/consts.dart';
import 'components/order_place_details.dart';
import 'components/order_status.dart';
import 'package:intl/intl.dart' as intl;

class OrderDetails extends StatelessWidget {
  final dynamic data;
  const OrderDetails({Key? key, this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: whiteColor,
      appBar: AppBar(
        title: "Order Details"
            .text
            .fontFamily(semibold)
            .color(darkFontGrey)
            .make(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              orderStatus(
                color: redColor,
                title: "Placed",
                icon: Icons.done,
                showDone: data['order_placed'],
              ),
              orderStatus(
                color: Colors.blue,
                title: "Confirmed",
                icon: Icons.thumb_up,
                showDone: data['order_confirmed'],
              ),
              orderStatus(
                color: Colors.yellow,
                title: "On Delivery",
                icon: Icons.car_crash,
                showDone: data['order_on_delivery'],
              ),
              orderStatus(
                color: Colors.purple,
                title: "Delivered",
                icon: Icons.done_all,
                showDone: data['order_delivered'],
              ),
              const Divider(),
              10.heightBox,
              Column(
                children: [
                  orderPlaceDetails(
                    title1: "Order Code",
                    data1: data['order_code'],
                    title2: "Shipping Method",
                    data2: data['shipping_method'],
                  ),
                  orderPlaceDetails(
                    title1: "Order Date",
                    data1: intl.DateFormat()
                        .add_yMd()
                        .format(data['order_date'].toDate()),
                    title2: "Payment Method",
                    data2: data['payment_method'],
                  ),
                  orderPlaceDetails(
                    title1: "Payment Status",
                    data1: "Unpaid",
                    title2: "Delivery Status",
                    data2: "Order Placed",
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            "Shipping Address".text.color(darkFontGrey).make(),
                            "Name: ${data['order_by_name']}".text.make(),
                            "Email: ${data['order_by_email']}".text.make(),
                            "Address: ${data['order_by_address']}".text.make(),
                            "City: ${data['order_by_city']}".text.make(),
                            "Country: Pakistan".text.make(),
                            "State: ${data['order_by_state']}".text.make(),
                            "phone: ${data['order_by_phone']}".text.make(),
                            "Postal Code: ${data['order_by_postalcode']}"
                                .text
                                .make(),
                          ],
                        ),
                        SizedBox(
                          width: 130,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              "Total Amount".text.fontFamily(semibold).make(),
                              "${data['total_amount']}"
                                  .text
                                  .color(redColor)
                                  .fontFamily(bold)
                                  .make()
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ).box.outerShadowMd.white.make(),
              const Divider(),
              10.heightBox,
              "Order Product"
                  .text
                  .size(16)
                  .color(darkFontGrey)
                  .fontFamily(semibold)
                  .make(),
              10.heightBox,
              ListView(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                children: List.generate(data["orders"].length, (index) {
                  return Column(
                    children: [
                      orderPlaceDetails(
                          title1: data["orders"][index]['title'],
                          title2: data["orders"][index]['total_price'],
                          data1: "${data["orders"][index]['qty']}",
                          data2: "${data["orders"][index]['Refundable']}"),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Container(
                          width: 30,
                          height: 20,
                          color: Color(data["orders"][index]['color']),
                        ),
                      ),
                      const Divider()
                    ],
                  );
                }).toList(),
              ).box.white.shadowMd.make(),
              10.heightBox,
            ],
          ),
        ),
      ),
    );
  }
}
