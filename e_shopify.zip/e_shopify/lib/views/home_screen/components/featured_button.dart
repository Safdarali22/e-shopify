import 'package:e_shoping_updated/consts/consts.dart';
import 'package:e_shoping_updated/views/category_screen/category_details.dart';

Widget featuredButton({String? title, icon}) {
  int? name=0;
  return Row(
    children: [
      Image.asset(
        icon,
        width: 60,
        fit: BoxFit.fill,
      ),
      10.widthBox,
      title!.text.fontFamily(semibold).color(fontGrey).center.make()
    ],
  )
      .box
      .white
      .width(220)
      .margin(const EdgeInsets.all(4))
      .padding(const EdgeInsets.all(4))
      .roundedSM
      .outerShadowSm
      .make().onTap(() {
        Get.to(()=>CategoryDetails(title: name));
  });
}
