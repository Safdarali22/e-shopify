import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shoping_updated/controllers/home_controller.dart';
import 'package:e_shoping_updated/views/category_screen/item_details.dart';
import 'package:e_shoping_updated/views/home_screen/search_screen.dart';

import '../../consts/consts.dart';
import '../../consts/lists.dart';
import '../../widgets_common/home_buttons.dart';
import 'components/featured_button.dart';

class HomeScreen extends StatelessWidget {

  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<HomeController>();

    return Container(
      color: lightGrey,
      padding: const EdgeInsets.all(12),
      height: context.screenHeight,
      width: context.screenWidth,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              alignment: Alignment.center,
              height: 60,
              color: lightGrey,
              child: Text('$appname')
              // TextFormField(
              //   controller: controller.searchController,
              //   decoration:  InputDecoration(
              //       border: InputBorder.none,
              //       suffixIcon: Icon(Icons.search).onTap(() {
              //         if(controller.searchController.text.isNotEmptyAndNotNull){
              //           Get.to(()=>SearchScreen(title: controller.searchController.text,));
              //           controller.searchController.clear();
              //         }
              //       }),
              //       hintText: searchAnything,
              //       filled: true,
              //       fillColor: whiteColor,
              //       hintStyle: TextStyle(color: textFieldGrey)),
              // ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    VxSwiper.builder(
                      enlargeCenterPage: true,
                      aspectRatio: 16 / 9,
                      autoPlay: true,
                      height: 150,
                      itemCount: sliderList.length,
                      itemBuilder: (_, index) => Container(
                        child: Image.asset(
                          sliderList[index],
                          fit: BoxFit.fill,
                        )
                            .box
                            .rounded
                            .clip(Clip.antiAlias)
                            .margin(const EdgeInsets.symmetric(horizontal: 8))
                            .make(),
                      ),
                    ),
                    5.heightBox,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(
                        2,
                        (index) => homeButton(
                            width: context.screenWidth / 2.5,
                            height: context.screenHeight * 0.15,
                            icon: index == 0 ? icTodaysDeal : icFlashDeal,
                            title: index == 0 ? todayDeal : flashSale),
                      ),
                    ).onTap(() {

                    }),
                    5.heightBox,
                    VxSwiper.builder(
                      enlargeCenterPage: true,
                      aspectRatio: 16 / 9,
                      autoPlay: true,
                      height: 150,
                      itemCount: secondSliderList.length,
                      itemBuilder: (_, index) => Container(
                        child: Image.asset(
                          secondSliderList[index],
                          fit: BoxFit.fill,
                        )
                            .box
                            .rounded
                            .clip(Clip.antiAlias)
                            .margin(const EdgeInsets.symmetric(horizontal: 8))
                            .make(),
                      ),
                    ),
                    10.heightBox,
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(
                        3,
                        (index) => homeButton(
                            height: context.screenHeight * 0.15,
                            width: context.screenWidth / 3.5,
                            icon: index == 0
                                ? icTopCategories
                                : index == 1
                                    ? icBrands
                                    : icTopSeller,
                            title: index == 0
                                ? topCategories
                                : index == 1
                                    ? brands
                                    : topSellers),
                      ),
                    ),
                    // featured Categories...
                    20.heightBox,
                    Align(
                      alignment: Alignment.centerLeft,
                      child: featuredCategories.text
                          .color(darkFontGrey)
                          .size(16)
                          .fontFamily(semibold)
                          .make(),
                    ),
                    20.heightBox,
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          3,
                          (index) => Column(
                            children: [
                              featuredButton(
                                  title: featuredTitles1[index],
                                  icon: featuredImages1[index]),
                              10.heightBox,
                              featuredButton(
                                  title: featuredTitles2[index],
                                  icon: featuredImages2[index]),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Featured Products..
                    Container(
                      padding: const EdgeInsets.all(12),
                      width: double.infinity,
                      color: redColor,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          featuredProduct.text.white
                              .fontFamily(bold)
                              .size(18)
                              .make(),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: FutureBuilder(
                              future: FirestoreServices.getFeaturedProducts(),
                              builder: ( context, AsyncSnapshot<QuerySnapshot>  snapshot) {
                                if(!snapshot.hasData){
                                  return Center(
                                    child: loadingIndicator(),
                                  );
                                }else if(snapshot.data!.docs.isEmpty){
                                  return "No Featured Products".text.white.makeCentered();

                                }else{
                                  var featuredData = snapshot.data!.docs;
                                  return Row(
                                    children: List.generate(
                                      featuredData.length,
                                          (index) => Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Image.network(
                                            featuredData[index]['p_images'][0],
                                            width: 150,
                                            height: 130,
                                            fit: BoxFit.cover,
                                          ),
                                          10.heightBox,
                                          "${ featuredData[index]['p_name']}"
                                              .text
                                              .fontFamily(semibold)
                                              .color(darkFontGrey)
                                              .make(),
                                          10.heightBox,
                                          "${ featuredData[index]['p_price']}".numCurrency
                                              .text
                                              .color(redColor)
                                              .size(16)
                                              .fontFamily(bold)
                                              .make()
                                        ],
                                      )
                                          .box
                                          .white
                                          .roundedSM
                                          .margin(const EdgeInsets.symmetric(
                                          horizontal: 4))
                                          .padding(const EdgeInsets.all(8))
                                          .make().onTap(() {
                                            Get.to(()=>ItemDetails(
                                              data: featuredData[index],
                                            ));
                                          }),
                                    ),
                                  );
                                }


                              },


                            ),
                          ),
                        ],
                      ),
                    ),
                    20.heightBox,
                    // 3RD Swiper
                    VxSwiper.builder(
                      enlargeCenterPage: true,
                      aspectRatio: 16 / 9,
                      autoPlay: true,
                      height: 150,
                      itemCount: secondSliderList.length,
                      itemBuilder: (_, index) => Container(
                        child: Image.asset(
                          secondSliderList[index],
                          fit: BoxFit.fill,
                        )
                            .box
                            .rounded
                            .clip(Clip.antiAlias)
                            .margin(const EdgeInsets.symmetric(horizontal: 8))
                            .make(),
                      ),
                    ),
                    20.heightBox,
                    StreamBuilder(stream: FirestoreServices.allproducts(), builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot){
                      if(!snapshot.hasData){
                        return loadingIndicator();
                      }else{
                        var allproductsdata = snapshot.data!.docs;
                        return GridView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: allproductsdata.length,
                          gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 8,
                              crossAxisSpacing: 8,
                              mainAxisExtent: 300),
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.network(
                                  allproductsdata[index]['p_images'][0],
                                  width: 200,
                                  height: 200,
                                  fit: BoxFit.cover,
                                ),
                                const Spacer(),
                                "${
                                allproductsdata[index]['p_name']

                                }"
                                    .text
                                    .fontFamily(semibold)
                                    .color(darkFontGrey)
                                    .make(),
                                10.heightBox,
                                "${
                            allproductsdata[index]['p_price']

                                }"
                                    .text
                                    .color(redColor)
                                    .size(16)
                                    .fontFamily(bold)
                                    .make()
                              ],
                            )
                                .box
                                .white
                                .roundedSM
                                .margin(const EdgeInsets.symmetric(horizontal: 4))
                                .padding(const EdgeInsets.all(12))
                                .make().onTap(() {
                                  Get.to(()=>ItemDetails(
                                    data: allproductsdata[index],
                                  ));
                            });
                          },
                        );
                      }


                    })
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
