import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shoping_updated/views/cart_screen/shiping_screen.dart';
import 'package:e_shoping_updated/widgets_common/our_button.dart';

import '../../consts/consts.dart';
import '../../controllers/cart_controller.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(CartController());
    return Scaffold(
      bottomNavigationBar: SizedBox(
        width: context.screenWidth - 30,
        child: ourButton(
            onpress: () {
              Get.to(() => const ShippingDetails());
            },
            title: "Proceed to Shipping",
            bgColor: redColor,
            textColor: whiteColor),
      ),
      backgroundColor: whiteColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title:
            "Shoping Cart".text.fontFamily(semibold).color(darkFontGrey).make(),
      ),
      body: StreamBuilder(
          stream: FirestoreServices.getCartItems(currentUser!.uid),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return loadingIndicator();
            } else if (snapshot.data!.docs.isEmpty) {
              return Center(
                child: "No Item in Cart"
                    .text
                    .size(18)
                    .color(darkFontGrey)
                    .fontFamily(bold)
                    .make(),
              );
            } else {
              var data = snapshot.data!.docs;
              controller.calculateTotalAmount(data);
              controller.productSnapshot = data;
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                          itemCount: data.length,
                          itemBuilder: (_, index) {
                            return ListTile(
                                leading: Image.network(
                                  data[index]['image'],
                                  width: 80,
                                  fit: BoxFit.cover,
                                ),
                                title:
                                    "${data[index]['title']} ( x${data[index]['quantity']} )"
                                        .text
                                        .fontFamily(semibold)
                                        .size(16)
                                        .make(),
                                subtitle: "${data[index]['total_price']}"
                                    .numCurrency
                                    .text
                                    .color(redColor)
                                    .fontFamily(semibold)
                                    .make(),
                                trailing: IconButton(
                                  onPressed: () {
                                    FirestoreServices.deleteCartItem(
                                        data[index].id);
                                  },
                                  icon: const Icon(
                                    Icons.delete,
                                    color: redColor,
                                  ),
                                ));
                          }),
                    ),
                    Obx(
                      () => Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                            "Total Price"
                                .text
                                .fontFamily(semibold)
                                .color(darkFontGrey)
                                .make(),
                            "${controller.totalPrice.value}"
                                .numCurrency
                                .text
                                .color(redColor)
                                .fontFamily(semibold)
                                .make()
                          ])
                          .box
                          .padding(const EdgeInsets.all(12))
                          .width(context.screenWidth - 30)
                          .color(lightGolden)
                          .roundedSM
                          .make(),
                    ),
                  ],
                ),
              );
            }
          }),
    );
  }
}
