import 'package:e_shoping_updated/consts/consts.dart';
import 'package:e_shoping_updated/views/cart_screen/payment_method.dart';
import 'package:e_shoping_updated/widgets_common/custom_textfield.dart';
import 'package:e_shoping_updated/widgets_common/our_button.dart';

import '../../controllers/cart_controller.dart';

class ShippingDetails extends StatelessWidget {
  const ShippingDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<CartController>();
    return Scaffold(
      backgroundColor: whiteColor,
      appBar: AppBar(
        title: "Shipping Info"
            .text
            .fontFamily(semibold)
            .color(darkFontGrey)
            .make(),
      ),
      bottomNavigationBar: SizedBox(
        height: 60,
        child: ourButton(
            bgColor: redColor,
            title: 'Continue',
            onpress: () {
              if (controller.addressController.text.length > 8) {
                Get.to(() => const PaymentMethods());
              } else {
                VxToast.show(context, msg: "Please fill the Form Correctly");
              }
            },
            textColor: whiteColor),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              customTextField(
                  controller: controller.addressController,
                  title: "Address",
                  ispass: false,
                  hint: "Address"),
              customTextField(
                  controller: controller.cityController,
                  title: "City",
                  ispass: false,
                  hint: "City"),
              customTextField(
                  controller: controller.stateController,
                  title: "State",
                  ispass: false,
                  hint: "State"),
              customTextField(
                  controller: controller.postalcodeController,
                  title: "Postal Code",
                  ispass: false,
                  hint: "Postal Code"),
              customTextField(
                  controller: controller.phoneController,
                  title: "Phone",
                  ispass: false,
                  hint: "Phone"),
            ],
          ),
        ),
      ),
    );
  }
}
