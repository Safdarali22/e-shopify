import 'dart:developer';

import '../../consts/consts.dart';
import '../../controllers/auth_controller.dart';
import '../../widgets_common/applogo_widget.dart';
import '../../widgets_common/bg_widget.dart';
import '../../widgets_common/custom_textfield.dart';
import '../../widgets_common/our_button.dart';
import '../home_screen/home.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  bool? isCheck = false;

  var controller = Get.put(AuthController());

  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var passwordRetypeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return bgWidget(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: Column(
            children: [
              (context.screenHeight * 0.1).heightBox,
              appLogoWidget(),
              10.heightBox,
              "Join the $appname".text.fontFamily(bold).white.size(18).make(),
              15.heightBox,
              Obx(
                () => Column(
                  children: [
                    customTextField(
                        title: name,
                        hint: nameHint,
                        controller: nameController,
                        ispass: false),
                    customTextField(
                        title: email,
                        hint: emailHint,
                        controller: emailController,
                        ispass: false),
                    customTextField(
                        title: password,
                        hint: passwordHint,
                        controller: passwordController,
                        ispass: true),
                    customTextField(
                        title: retypePassword,
                        hint: passwordHint,
                        controller: passwordRetypeController,
                        ispass: true),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {},
                        child: forgetPassword.text.make(),
                      ),
                    ),
                    5.heightBox,
                    Row(
                      children: [
                        Checkbox(
                            checkColor: redColor,
                            value: isCheck,
                            onChanged: (newValue) {
                              setState(() {
                                isCheck = newValue;
                              });
                            }),
                        Expanded(
                          child: RichText(
                            text: const TextSpan(
                              children: [
                                TextSpan(
                                  text: "I agree to the ",
                                  style: TextStyle(
                                      fontFamily: regular, color: fontGrey),
                                ),
                                TextSpan(
                                  text: termsAndConditions,
                                  style: TextStyle(
                                    fontFamily: regular,
                                    color: redColor,
                                  ),
                                ),
                                TextSpan(
                                  text: "& ",
                                  style: TextStyle(
                                    fontFamily: regular,
                                    color: fontGrey,
                                  ),
                                ),
                                TextSpan(
                                  text: privacyPolicy,
                                  style: TextStyle(
                                    fontFamily: regular,
                                    color: redColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                    controller.isLoading.value
                        ? const CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(redColor),
                          )
                        : ourButton(
                                title: signUp,
                                bgColor: isCheck == true ? redColor : lightGrey,
                                onpress: () async {
                                  if (emailController.text.isEmpty ||
                                      passwordController.text.isEmpty ||
                                      passwordRetypeController.text.isEmpty ||
                                      nameController.text.isEmpty) {
                                    VxToast.show(context,
                                        msg: "Please fill all fields!",
                                        bgColor: Colors.red,
                                        textColor: Colors.white);
                                  } else {
                                    try {
                                      if (isCheck != false) {
                                        controller.isLoading(true);
                                        print(
                                            "Email Controller: ${emailController.text}");
                                        print(
                                            "Password Controller: ${passwordController.text}");
                                        print(
                                            "Name Controller: ${nameController.text}");
                                        await controller
                                            .signupMethod(
                                                context: context,
                                                email: emailController.text,
                                                password:
                                                    passwordController.text)
                                            .then((value) {
                                          if (value != null) {
                                            VxToast.show(context,
                                                msg: loggedIn);
                                            Get.offAll(() => const Home());
                                            return controller.storeUserData(
                                                name: nameController.text,
                                                password:
                                                    passwordController.text,
                                                email: emailController.text);
                                          }
                                          controller.isLoading(false);

                                          log("NULL");
                                        });
                                      }
                                    } catch (e) {
                                      VxToast.show(context, msg: e.toString());
                                      print("Msg $e");
                                      auth.signOut();
                                      controller.isLoading(false);
                                    }
                                  }
                                },
                                textColor: whiteColor)
                            .box
                            .width(context.screenWidth - 50)
                            .make(),
                    5.heightBox,
                    RichText(
                      text: const TextSpan(
                        children: [
                          TextSpan(
                            text: alreadyhaveAccount,
                            style: TextStyle(
                              fontFamily: bold,
                              color: fontGrey,
                            ),
                          ),
                          TextSpan(
                            text: " $login",
                            style: TextStyle(
                              fontFamily: bold,
                              color: redColor,
                            ),
                          )
                        ],
                      ),
                    ).onTap(() {
                      Get.back();
                    })
                  ],
                )
                    .box
                    .white
                    .rounded
                    .shadowSm
                    .padding(const EdgeInsets.all(16))
                    .width(context.screenWidth - 70)
                    .make(),
              )
            ],
          ),
        ),
      ),
    );
  }
}
