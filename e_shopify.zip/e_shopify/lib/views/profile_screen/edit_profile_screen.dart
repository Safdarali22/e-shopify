import 'dart:io';

import 'package:e_shoping_updated/consts/consts.dart';
import 'package:e_shoping_updated/controllers/profile_controller.dart';
import 'package:e_shoping_updated/views/profile_screen/profile_screen.dart';
import 'package:e_shoping_updated/widgets_common/bg_widget.dart';
import 'package:e_shoping_updated/widgets_common/custom_textfield.dart';

import '../../widgets_common/our_button.dart';

class EditProfileScreen extends StatelessWidget {
  final dynamic data;
  const EditProfileScreen({super.key, this.data});

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<ProfileController>();

    return bgWidget(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(),
        body: Obx(
          () => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              data['imageUrl'] == '' && controller.profileImgPath.isEmpty
                  ? Image.asset(imgProfile2, width: 100, fit: BoxFit.cover)
                      .box
                      .roundedFull
                      .clip(Clip.antiAlias)
                      .make()
                  : data['imageUrl'] != '' &&
                          controller.profileImgPath.isEmpty
                      ? Image.network(data['imageUrl'],
                              width: 100, fit: BoxFit.cover)
                          .box
                          .roundedFull
                          .clip(Clip.antiAlias)
                          .make()
                      : Image.file(
                          File(controller.profileImgPath.value),
                          width: 100,
                          fit: BoxFit.cover,
                        ).box.roundedFull.clip(Clip.antiAlias).make(),
              10.heightBox,
              ourButton(
                  bgColor: redColor,
                  onpress: () {
                    controller.changeImage(context);
                  },
                  title: 'Change',
                  textColor: whiteColor),
              const Divider(),
              20.heightBox,
              customTextField(
                  title: name,
                  hint: nameHint,
                  ispass: false,
                  controller: controller.nameController),
              customTextField(
                  title: oldPassword,
                  hint: passwordHint,
                  ispass: false,
                  controller: controller.oldPasswordController),
              customTextField(
                  title: newpassword,
                  hint: passwordHint,
                  ispass: false,
                  controller: controller.newPasswordController),
              20.heightBox,
              controller.isLoading.value
                  ? const CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(redColor),
                    )
                  : SizedBox(
                      width: context.screenWidth - 60,
                      child: ourButton(
                          bgColor: redColor,
                          onpress: () async {
                            controller.isLoading(true);
                            if (controller
                                .profileImgPath.value.isNotEmpty) {
                              await controller.uploadProfileImage();
                            } else {
                              controller.profileImageLink =
                                  data['imageUrl'];
                            }
                            //if old password matches database password; then we will update it.
                            if (controller.oldPasswordController.text ==
                                data['password']) {
                              // first Authorized it...
                              controller.changeAuthPassword(
                                  email: data['email'],
                                  password: controller
                                      .oldPasswordController.text,
                                  newPassword: controller
                                      .newPasswordController.text);

                              await controller.updateProfile(
                                name: controller.nameController.text,
                                password: controller
                                    .newPasswordController.text,
                                imageUrl:controller.profileImageLink,
                              );
                              Get.offAll(() =>  ProfileScreen());
                              VxToast.show(context, msg: "Profile Updated");
                            } else {
                              VxToast.show(context,
                                  msg: "Wrong Old Password Provided");
                              controller.isLoading(false);
                            }
                          },
                          title: 'Save',
                          textColor: whiteColor),
                    ),
            ],
          )
              .box
              .white
              .shadowSm
              .rounded
              .padding(const EdgeInsets.all(16))
              .margin(const EdgeInsets.only(top: 50, left: 12, right: 12))
              .make(),
        ),
      ),
    );
  }
}
