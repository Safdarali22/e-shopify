import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shoping_updated/controllers/profile_controller.dart';
import 'package:e_shoping_updated/views/chat_screen/messaging_screen.dart';
import 'package:e_shoping_updated/views/orders_screen/orders_screen.dart';
import 'package:e_shoping_updated/views/wishlist_screen/wishlist_screen.dart';
import 'package:e_shoping_updated/widgets_common/bg_widget.dart';
import '../../consts/consts.dart';
import '../../consts/lists.dart';
import '../../controllers/auth_controller.dart';
import '../auth_screen/login_screen.dart';
import 'detailsCart.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatelessWidget {
 var  controller = Get.put(ProfileController());

  ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return bgWidget(
      child: Scaffold(
          body: StreamBuilder(
              stream: FirestoreServices.getUser(currentUser!.uid),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(redColor),
                  ));
                } else if (!snapshot.hasData) {
                  return const Center(
                    child: Text("No Data Found!"),
                  );
                } else if (snapshot.hasError) {
                  return const Center(
                    child: Text("Something wents wrong!"),
                  );
                } else {
                  var data = snapshot.data!.docs[0];
                  var controller = Get.find<ProfileController>();
                  return SafeArea(
                    child: Column(
                      children: [
                        //Edit profile
                        Align(
                          alignment: Alignment.topRight,
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                          ).onTap(() {
                            controller.nameController.text = data['name'];

                            Get.to(() => EditProfileScreen(data: data));
                          }),
                        ),
                        // User details
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            children: [
                              data['imageUrl'] == ''
                                  ? Image.asset(
                                      "assets/images/placeholder_image.png",
                                      width: 75,
                                      fit: BoxFit.cover,
                                    )
                                      .box
                                      .roundedFull
                                      .clip(Clip.antiAlias)
                                      .make()
                                  : Image.network(
                                      '${data['imageUrl']}',
                                      width: 75,
                                      fit: BoxFit.cover,
                                    )
                                      .box
                                      .roundedFull
                                      .clip(Clip.antiAlias)
                                      .make(),
                              5.widthBox,
                              Expanded(
                                  child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  "${data['name']}"
                                      .text
                                      .size(16)
                                      .fontFamily(semibold)
                                      .white
                                      .make(),
                                  "${data['email']}".text.size(12).white.make()
                                ],
                              )),
                              OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                      padding: EdgeInsets.zero,
                                      fixedSize: const Size(100, 40),
                                      side: const BorderSide(
                                          color: Colors.white)),
                                  onPressed: () async {
                                    print("Logout....");
                                    var controller = Get.put(AuthController());
                                    controller.signOutMethod(context);
                                    Get.offAll(() =>  LoginScreen());
                                  },
                                  child: Center(
                                    child: logOut.text
                                        .fontFamily(semibold)
                                        .white
                                        .make(),
                                  ))
                            ],
                          ),
                        ),
                        FutureBuilder(
                            future: FirestoreServices.getCounts(),
                            builder: (BuildContext context, AsyncSnapshot snapshot) {
                              if (!snapshot.hasData){
                                return Center(child: loadingIndicator(),);
                              }else{
                                var CountData = snapshot.data;
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  children: [
                                    detailsCart(
                                        title: "in you cart",
                                        count: "${CountData[0].toString()}",
                                        width: context.screenWidth / 3.2),
                                    detailsCart(
                                        title: "in you wishlist",
                                        count: "${CountData[1].toString()}",
                                        width: context.screenWidth / 3.0),
                                    detailsCart(
                                        title: "in you Orders",
                                        count: "${CountData[2].toString()}",
                                        width: context.screenWidth / 3.2),
                                  ],
                                );
                              }
                              }),
                        //

                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        //   children: [
                        //     detailsCart(
                        //         title: "in you cart",
                        //         count: "${data['cart_count']}",
                        //         width: context.screenWidth / 3.2),
                        //     detailsCart(
                        //         title: "in you wishlist",
                        //         count: "${data['wishlist_count']}",
                        //         width: context.screenWidth / 3.2),
                        //     detailsCart(
                        //         title: "in you Orders",
                        //         count: "${data['order_count']}",
                        //         width: context.screenWidth / 3.2),
                        //   ],
                        // ),
                        bgWidgetforProfile(
                          child: ListView.separated(
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return ListTile(
                                      onTap: () {
                                        switch (index) {
                                          case 0:
                                            Get.to(() => const OrdersScreen());
                                            break;
                                          case 1:
                                            Get.to(
                                                () => const WishlistScreen());
                                            break;
                                          case 2:
                                            Get.to(
                                                () => const MessagesScreen());
                                            break;
                                        }
                                      },
                                      leading: Image.asset(
                                        profileButtonIcons[index],
                                        width: 20,
                                      ),
                                      title: profileButtonsList[index]
                                          .text
                                          .fontFamily(semibold)
                                          .color(darkFontGrey)
                                          .make(),
                                    );
                                  },
                                  separatorBuilder: (context, index) {
                                    return const Divider(
                                      height: 10,
                                      color: Colors.red,
                                    );
                                  },
                                  itemCount: profileButtonsList.length)
                              .box
                              .white
                              .padding(
                                const EdgeInsets.symmetric(horizontal: 16),
                              )
                              .shadowSm
                              .rounded
                              .margin(const EdgeInsets.only(
                                  left: 20, right: 20, top: 10))
                              .make(),
                        )
                      ],
                    ),
                  );
                }
              })),
    );
  }
}
