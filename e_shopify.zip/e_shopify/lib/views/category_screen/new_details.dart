// import 'package:e_shoping_updated/widgets_common/bg_widget.dart';
//
// import '../../consts/consts.dart';
//
// class newCategory extends StatelessWidget {
//   final String? title;
//   const newCategory({super.key, this.title});
//
//   @override
//   Widget build(BuildContext context) {
//     return bgWidget(
//       child: Scaffold(
//         appBar: AppBar(
//           title: title!.text.fontFamily(bold).white.make(),
//         ),
//         body: Container(
//           padding: const EdgeInsets.all(12),
//           child: Column(
//             children: [
//               SingleChildScrollView(
//                 scrollDirection: Axis.horizontal,
//                 child: Row(
//                   children: List.generate(6, (index) => "Baby Clothing".text.fontFamily(semibold).color(darkFontGrey).makeCentered().box.white.rounded.size(150, 60).margin(const EdgeInsets.symmetric(horizontal: 4)).make()),
//                 ),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
