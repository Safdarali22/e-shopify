// import 'package:e_shoping_updated/widgets_common/bg_widget.dart';
//
// import '../../consts/consts.dart';
// import '../../consts/lists.dart';
//
// class newCategory extends StatelessWidget {
//   const newCategory({super.key, required String title});
//
//   @override
//   Widget build(BuildContext context) {
//     return bgWidget(
//       child: Scaffold(
//         appBar: AppBar(
//           title: categories.text.fontFamily(bold).white.make(),
//         ),
//         body: Container(
//           padding: const EdgeInsets.all(12),
//           child: GridView.builder(
//               // itemCount: categoriesList.length,
//               itemCount: 9,
//               shrinkWrap: true,
//               gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount( crossAxisCount: 3,
//               mainAxisSpacing: 8,
//               crossAxisSpacing: 8,
//               mainAxisExtent: 220),
//             itemBuilder: (context, index){
//             return Column(
//               children: [Image.asset(categoryImages[index],height: 120,width: 200,fit: BoxFit.cover,),
//               10.heightBox,
//                 categoriesList[index]
//                     .text
//                     .color(darkFontGrey)
//                     .align(TextAlign.center)
//                     .make()],
//             ).box.white.rounded.clip(Clip.antiAlias)
//                 .outerShadowSm.make().onTap(() {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(builder: (context) =>  newCategory(title: categoriesList[index])),
//               );
//               // Get.to(()=>newCategory(title: categoriesList[index]));
//             });
//
//             }
//         ),
//         ),
//       ),
//     );
//   }
// }
