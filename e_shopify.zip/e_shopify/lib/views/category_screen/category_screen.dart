import 'package:e_shoping_updated/consts/lists.dart';
import 'package:e_shoping_updated/widgets_common/bg_widget.dart';

import '../../consts/consts.dart';
import '../../controllers/product_controller.dart';
import 'category_details.dart';

class CategoryScreen extends StatelessWidget {

   CategoryScreen({super.key});


  @override
  Widget build(BuildContext context) {
    var productController = Get.put(ProductController());

    productController.getCategoreis();
    // print(productController.categories);

    return bgWidget(
      child: Scaffold(
        appBar: AppBar(
          title: categories.text.white.fontFamily(bold).make(),
        ),
        body: Container(
          padding: const EdgeInsets.all(12),
          child: Obx(
            () => GridView.builder(
                itemCount: productController.categories.length,
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    mainAxisExtent: 220),
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Image.asset(
                        categoriesImages[index],
                        width: 200,
                        height: 120,
                        fit: BoxFit.cover,
                      ),
                      10.heightBox,
                      "${productController.categories[index]}"
                          .text
                          .color(darkFontGrey)
                          .align(TextAlign.center)
                          .make()
                    ],
                  )
                      .box
                      .white
                      .rounded
                      .clip(Clip.antiAlias)
                      .outerShadowSm
                      .make()
                      .onTap(() {
                    Get.to(() =>
                         CategoryDetails(title: index));

                  });
                }),
          ),
        ),
      ),
    );
  }
}
