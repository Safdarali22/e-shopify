import 'package:e_shoping_updated/consts/lists.dart';
import 'package:e_shoping_updated/controllers/product_controller.dart';
import 'package:e_shoping_updated/widgets_common/our_button.dart';

import '../../consts/consts.dart';
import '../chat_screen/chat_screen.dart';

class ItemDetails extends StatelessWidget {
  final dynamic data;
  const ItemDetails({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(ProductController());
    return WillPopScope(
      onWillPop: () async {
        controller.resetValues();
        return true;
      },
      child: Scaffold(
        backgroundColor: lightGrey,
        appBar: AppBar(
          leading: IconButton(
              onPressed: () {
                controller.resetValues();
                Get.back();
              },
              icon: const Icon(Icons.arrow_back)),
          title: "${data['p_name']}".text.color(darkFontGrey).make(),
          actions: [
            IconButton(
              onPressed: () {},
              icon: const Icon(
                Icons.share,
              ),
            ),
            Obx(
              () => IconButton(
                onPressed: () {
                  if (controller.isFav.value) {
                    controller.removeFromWishlist(data.id, context);
                  } else {
                    controller.addToWishlist(data.id, context);
                  }
                },
                icon: Icon(
                  Icons.favorite_outlined,
                  color: controller.isFav.value ? redColor : darkFontGrey,
                ),
              ),
            )
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Swiper Selection
                      VxSwiper.builder(
                          autoPlay: true,
                          aspectRatio: 16 / 9,
                          viewportFraction: 1.0,
                          height: 350,
                          itemCount: data['p_images'].length,
                          itemBuilder: (_, index) => Image.network(
                                data['p_images'][index],
                                width: double.infinity,
                                fit: BoxFit.cover,
                              )),
                      10.heightBox,
                      //title and details section..
                      "${data['p_name']}"
                          .text
                          .size(18)
                          .fontFamily(semibold)
                          .color(darkFontGrey)
                          .make(),
                      10.heightBox,
                      VxRating(
                        isSelectable: false,
                        value: double.parse(data['p_rating']),
                        onRatingUpdate: (value) {},
                        normalColor: textFieldGrey,
                        selectionColor: lightGolden,
                        maxRating: 5,
                        count: 5,
                        size: 25,
                        stepInt: true,
                      ),
                      10.heightBox,
                      "${data['p_price']}"
                          .numCurrency
                          .text
                          .fontFamily(bold)
                          .color(redColor)
                          .size(18)
                          .make()

                      // Message
                      ,
                      10.heightBox,
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                "seller "
                                    .text
                                    .white
                                    .fontFamily(semibold)
                                    .make(),
                                5.heightBox,
                                "${data['p_seller']}"
                                    .text
                                    .color(darkFontGrey)
                                    .size(14)
                                    .fontFamily(semibold)
                                    .make()
                              ],
                            ),
                          ),
                          const CircleAvatar(
                            backgroundColor: Colors.white,
                            child: Icon(
                              Icons.message_rounded,
                              color: darkFontGrey,
                            ),
                          ).onTap(() {
                            Get.to(const ChatScreen(),
                                arguments: [
                              data['p_seller'],
                              data['vendor_id']
                            ]);
                          })
                        ],
                      )
                          .box
                          .height(60)
                          .padding(const EdgeInsets.symmetric(horizontal: 16))
                          .color(textFieldGrey)
                          .make()

                      // Color Section
                      ,
                      20.heightBox,
                      Obx(
                        () => Column(
                          children: [
                            Row(
                              children: [
                                SizedBox(
                                  width: 100,
                                  child: "Color : "
                                      .text
                                      .color(textFieldGrey)
                                      .make(),
                                ),
                                Row(
                                  children: List.generate(
                                      data['p_colors'].length,
                                      (index) => Stack(
                                            alignment: Alignment.center,
                                            children: [
                                              VxBox()
                                                  .size(40, 40)
                                                  .roundedFull
                                                  .color(Color(data['p_colors']
                                                          [index])
                                                      .withOpacity(1.0))
                                                  .margin(const EdgeInsets.symmetric(
                                                      horizontal: 6))
                                                  .make()
                                                  .onTap(() {
                                                controller
                                                    .changeColorIndex(index);
                                              }),
                                              Visibility(
                                                visible: index ==
                                                    controller.colorIndex.value,
                                                child: const Icon(Icons.done,
                                                    color: Colors.white),
                                              )
                                            ],
                                          )),
                                )
                              ],
                            ).box.padding(const EdgeInsets.all(8)).make(),
                            Row(
                              children: [
                                SizedBox(
                                  width: 100,
                                  child: "Quantity : "
                                      .text
                                      .color(textFieldGrey)
                                      .make(),
                                ),
                                Obx(
                                  () => Row(
                                    children: [
                                      IconButton(
                                        onPressed: () {
                                          if (controller.quantity.value > 0) {
                                            controller.decreaseQuantity();
                                            controller.calculateTotal(
                                                data['p_price']);
                                          }
                                        },
                                        icon: const Icon(Icons.remove),
                                      ),
                                      controller.quantity.value.text
                                          .size(16)
                                          .color(darkFontGrey)
                                          .fontFamily(bold)
                                          .make(),
                                      IconButton(
                                        onPressed: () {
                                          int quantity =
                                              int.parse(data['p_quantity']);
                                          if (controller.quantity.value <
                                              quantity) {
                                            controller.increaseQuantity();
                                            controller.calculateTotal(
                                                data['p_price']);
                                          }
                                        },
                                        icon: const Icon(Icons.add),
                                      ),
                                      10.widthBox,
                                      "(${data['p_quantity']} available)"
                                          .text
                                          .color(textFieldGrey)
                                          .make()
                                    ],
                                  ),
                                )
                              ],
                            ).box.padding(const EdgeInsets.all(8)).make(),
                            Row(
                              children: [
                                SizedBox(
                                  width: 100,
                                  child: "Total Price : "
                                      .text
                                      .color(textFieldGrey)
                                      .make(),
                                ),
                                "${controller.totalPrice}"
                                    .text
                                    .color(redColor)
                                    .size(16)
                                    .fontFamily(bold)
                                    .make()
                              ],
                            ).box.padding(const EdgeInsets.all(8)).make()
                          ],
                        ).box.white.shadowSm.make(),
                      ),

                      // Description Section...
                      10.heightBox,
                      "Description"
                          .text
                          .fontFamily(semibold)
                          .color(darkFontGrey)
                          .make(),
                      "${data["p_description"]}"
                          .text
                          .color(textFieldGrey)
                          .make(),
                      // Buttons Section...
                      20.heightBox,
                      ListView(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        children: List.generate(
                          itemDetailsButtonsList.length,
                          (index) => ListTile(
                            title: itemDetailsButtonsList[index]
                                .text
                                .fontFamily(semibold)
                                .color(darkFontGrey)
                                .make(),
                            trailing: const Icon(Icons.arrow_forward),
                          ),
                        ),
                      ),
                      20.heightBox,
                      productAlsoLike.text
                          .size(16)
                          .fontFamily(bold)
                          .color(darkFontGrey)
                          .make(),
                      20.heightBox,
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: List.generate(
                            6,
                            (index) => Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.asset(
                                  imgP1,
                                  width: 150,
                                  fit: BoxFit.cover,
                                ),
                                10.heightBox,
                                "Laptop 4GB/16GB"
                                    .text
                                    .fontFamily(semibold)
                                    .color(darkFontGrey)
                                    .make(),
                                10.heightBox,
                                "\$600"
                                    .text
                                    .color(redColor)
                                    .size(16)
                                    .fontFamily(bold)
                                    .make()
                              ],
                            )
                                .box
                                .white
                                .roundedSM
                                .margin(
                                    const EdgeInsets.symmetric(horizontal: 4))
                                .padding(const EdgeInsets.all(8))
                                .make(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 60,
              width: double.infinity,
              child: ourButton(
                  bgColor: redColor,
                  onpress: () {
                  if(controller.quantity.value>0){
                    var title = data['p_name'];
                    var image = data['p_images'][0];
                    var quantity = controller.quantity.value;
                    var totalPrice = controller.totalPrice.value;
                    var sellerName = data['p_seller'];
                    var color = data['p_colors'][controller.colorIndex.value];
                    var vendorId = data['vendor_id'];

                    controller.addToCart(
                        title: title,
                        context: context,
                        color: color,
                        image: image,
                        quantity: quantity,
                        vendorId: vendorId,
                        sellerName: sellerName,
                        totalPrice: totalPrice);
                    VxToast.show(context, msg: "Added to Cart");
                  }else{
                    VxToast.show(context, msg: "Quantity can't be Zero");
                  }
                  },
                  textColor: whiteColor,
                  title: "Add to Cart"),
            )
          ],
        ),
      ),
    );
  }
}
