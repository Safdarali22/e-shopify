import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shoping_updated/consts/consts.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthController extends GetxController {
  var isLoading = false.obs;

  var emailController = TextEditingController();
  var passwordController = TextEditingController();

  Future<UserCredential?> login({context}) async {
    UserCredential? userCredential;
    try {
      userCredential = await auth.signInWithEmailAndPassword(
          email: emailController.text, password: passwordController.text);
    } on FirebaseAuthException catch (e) {
      if (e.message!.contains("The email address is badly formatted.")) {
        VxToast.show(context, msg: "Email is not correct!");
      } else if (e.message!.contains(
          "There is no user record corresponding to this identifier. The user may have been deleted.")) {
        VxToast.show(context, msg: "No User found with this email!");
      } else if (e.message!.contains(
          "The password is invalid or the user does not have a password.")) {
        VxToast.show(context, msg: "Invalid Password!");
      } else {
        log(e.message.toString());
        VxToast.show(context, msg: e.message.toString());
      }
    }
    return userCredential;
  }

  // SignUp Method
  Future<UserCredential?> signupMethod(
      {String? email, String? password, context}) async {
    UserCredential? userCredential;
    try {
      userCredential = await auth.createUserWithEmailAndPassword(
          email: email!, password: password!);
    } on FirebaseAuthException catch (e) {
      if (e.message!.contains("Password should be at least 6 characters")) {
        VxToast.show(context, msg: "Password should be at least 6 characters!");
      } else if (e.message!.contains(
          "The email address is already in use by another account.")) {
        VxToast.show(context, msg: "Account with this email already exist!");
      } else if (e.message!.contains("The email address is badly formatted.")) {
        VxToast.show(context, msg: "Enter A valid email address!");
      } else {
        log(e.message.toString());

        VxToast.show(context, msg: e.message.toString());
      }
    }
    print(userCredential);
    return userCredential;
  }

  storeUserData({
    String? name,
    String? email,
    String? password,
  }) async {
    DocumentReference store =
        firestore.collection(usersCollection).doc(currentUser!.uid);
    store.set({
      'name': name,
      'email': email,
      'password': password,
      'imageUrl': '',
      'id': currentUser!.uid,
      'cart_count': '00',
      'wishlist_count': '00',
      'order_count': '00',
    });
  }

  signOutMethod(context) async {
    try {
      await auth.signOut();
    } catch (e) {
      VxToast.show(context, msg: e.toString());
    }
  }
}
