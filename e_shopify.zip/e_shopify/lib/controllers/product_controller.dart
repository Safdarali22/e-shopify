import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:e_shoping_updated/consts/consts.dart';
import 'package:flutter/services.dart';

class ProductController extends GetxController {
  var quantity = 0.obs;
  var totalPrice = 0.0.obs;

  var colorIndex = 0.obs;

  var subCat = [].obs;
  var categories = [].obs;

  var isFav = false.obs;

  ProductController() {
    getCategoreis();
  }

  getSubCetegories(int indexOfTitle) async {
    subCat.clear();
    String data =
        await rootBundle.loadString('lib/services/category_model.json');
    Map<String, dynamic> dataDecoded = await jsonDecode(data);
    List subCategories = dataDecoded['categories'][indexOfTitle]['subcategory'];

    for (var e in subCategories) {
      print(e);
      subCat.add(e);
    }
  }

  getCategoreis() async {
    categories.clear();
    var data = await rootBundle.loadString('lib/services/category_model.json');
    var dataDecoded = jsonDecode(data);
    for (var item in dataDecoded['categories']) {
      categories.add(item['name']);
      //print(item['name']);
    }
  }

  changeColorIndex(index) {
    colorIndex.value = index;
  }

  increaseQuantity() {
    quantity.value++;
  }

  decreaseQuantity() {
    quantity.value--;
  }

  calculateTotal(productPrice) {
    totalPrice.value = (quantity.value * double.parse(productPrice));
  }

  addToCart(
      {title,
      image,
      quantity,
      color,
      totalPrice,
      sellerName,
      context,
      vendorId}) async {
    await firestore.collection(cartCollection).doc().set({
      'title': title,
      'image': image,
      'quantity': quantity,
      'color': color,
      'total_price': totalPrice,
      'vendor_id': vendorId,
      'seller_name': sellerName,
      'added_by': currentUser!.uid
    }).catchError((error) {
      VxToast.show(context, msg: error.toString());
    });
  }

  resetValues() {
    quantity.value = 0;
    colorIndex.value = 0;
    totalPrice.value = 0;
  }

  addToWishlist(docId, context) async {
    await firestore.collection(productsCollection).doc(docId).set({
      'p_wishlist': FieldValue.arrayUnion([currentUser!.uid])
    }, SetOptions(merge: true));
    isFav(true);
    VxToast.show(context, msg: "Added to wishlist");
  }

  removeFromWishlist(docId, context) async {
    await firestore.collection(productsCollection).doc(docId).set({
      'p_wishlist': FieldValue.arrayRemove([currentUser!.uid])
    }, SetOptions(merge: true));
    isFav(false);
    VxToast.show(context, msg: "removed from wishlist");
  }

  checkIfFav(data) async {
    if (data['p_wishlist'].contains(currentUser!.uid)) {
      isFav(true);
    } else {
      isFav(false);
    }
  }
}
